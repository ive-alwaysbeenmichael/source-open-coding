﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

namespace finaltask2
{
    class Program
    {

        delegate void Del(string str);
        static void Main(string[] args)
        {
            int options = 0;
            float monthlyRental = 0;
            float fresh = 0;
            Dictionary<string, float> expenselist = new Dictionary<string, float>();//generic collection to store all the expenses
            Console.WriteLine("Gross monthly income");
            float grossIncome = 0;
            float.TryParse(Console.ReadLine(), out grossIncome);
            Console.WriteLine("Estimated monthly tax deducted");
            float taxDeducted = 0;
            float.TryParse(Console.ReadLine(), out taxDeducted);
            expenselist.Add("Estimated monthly tax deducted", taxDeducted);
            Console.WriteLine("Estimated monthly expenditures in  following categories");
            float groceries = 0;
            Console.WriteLine("Groceries");
            float.TryParse(Console.ReadLine(), out groceries);
            expenselist.Add("Groceries", groceries);
            float waterAndLights = 0;
            Console.WriteLine("Water and lights");
            float.TryParse(Console.ReadLine(), out waterAndLights);
            expenselist.Add("Water and lights", waterAndLights);
            float travelCosts = 0;
            Console.WriteLine("Travel costs (including petrol)");
            float.TryParse(Console.ReadLine(), out travelCosts);
            expenselist.Add("Travel costs (including petrol)", travelCosts);
            float cellPhone = 0;
            Console.WriteLine("Cell phone and telephone");
            float.TryParse(Console.ReadLine(), out cellPhone);
            expenselist.Add("Cell phone and telephone", cellPhone);
            float otherexpen = 0;
            Console.WriteLine("Other expenses");
            float.TryParse(Console.ReadLine(), out otherexpen);
            expenselist.Add("Other expenses", otherexpen);
            Console.WriteLine("For Renting accommodation  1 or  2 for buying a property");
            Console.WriteLine("1. Renting accommodation");
            Console.WriteLine("2. Buying a property");
            options = Convert.ToInt32(Console.ReadLine());
            if (options == 1)
            {
                Console.WriteLine("Monthly rental amount");
                float.TryParse(Console.ReadLine(), out monthlyRental);
                expenselist.Add("Monthly rental amount", monthlyRental);
            }
            else if (options == 2)
            {
                Console.WriteLine("Purchase price of property");
                float propertyPrice = 0;
                float.TryParse(Console.ReadLine(), out propertyPrice);
                float totalDeposit = 0;
                Console.WriteLine("Total deposit");
                float.TryParse(Console.ReadLine(), out totalDeposit);
                float interestRate = 0;
                Console.WriteLine("Interest rate (percentage)");
                float.TryParse(Console.ReadLine(), out interestRate);
                int monthrepay = 0;
                Console.WriteLine("Number of months - repay (between 240 and 360)");
                monthrepay = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Monthly home loan repayment for buying a property");
                fresh = calculator(propertyPrice - totalDeposit, interestRate, monthrepay / 12);
                if (fresh > grossIncome / 3)
                {
                    Console.WriteLine("Approval is unlikely");
                }
                expenselist.Add("Home Loan EMI", fresh);
            }
            float availableMoney = 0;
            if (options == 1)
            {
                availableMoney = grossIncome - (taxDeducted + groceries + waterAndLights + travelCosts + cellPhone + otherexpen + monthlyRental);

            }
            else if (options == 2)
            {
                availableMoney = grossIncome - (taxDeducted + groceries + waterAndLights + travelCosts + cellPhone + otherexpen + fresh);
            }
            Console.WriteLine("Available monthly money after  deductions have been made:{0}", availableMoney);
            float choice = BuyVehicle();
            if (choice > 0)
            {
                expenselist.Add("Vehicle fresh", choice);
            }
            float totalExpense = 0;
            if (options == 1)
            {
                totalExpense = taxDeducted + groceries + waterAndLights + travelCosts + cellPhone + monthlyRental + otherexpen + choice;
            }
            else if (options == 2)
            {
                totalExpense = taxDeducted + groceries + waterAndLights + travelCosts + cellPhone + otherexpen + fresh + choice;
            }
            if (totalExpense > (grossIncome * 3 / 4))
            {

                Del del3 = delegate (string name)
                { Console.WriteLine("Total expenses are greater than 75 percent of gross income"); };
            }
            //Display the expenses  in descending order 
            Console.WriteLine("Expenses in descending order ");
            foreach (KeyValuePair<string, float> expin in expenselist.OrderBy(key => key.Value))
            {
                Console.WriteLine(expin.Key + expin.Value);
            }
            Console.ReadLine();
        }
        static float calculator(float p, float r, float t)
        {
            float last;

            r = r / (12 * 100); //  month interest
            t = t * 12; // month period
            last = (p * r * (float)Math.Pow(1 + r, t))
            / (float)(Math.Pow(1 + r, t) - 1);

            return (last);
        }
        static float BuyVehicle()
        {
            Console.WriteLine("Want to buy a vehicle,  1 or 2");
            Console.WriteLine("1: Yes");
            Console.WriteLine("2: No");
            float vechilcek = 0;
            int selectvehicle = Convert.ToInt32(Console.ReadLine());
            if (selectvehicle == 1)
            {
                Console.WriteLine("Model and make");
                string make = Console.ReadLine();
                Console.WriteLine("Purchase price");
                float purchasePrice = 0;
                float.TryParse(Console.ReadLine(), out purchasePrice);
                Console.WriteLine("Total deposit");
                float totalDeposit = 0;
                float.TryParse(Console.ReadLine(), out totalDeposit);
                Console.WriteLine("Interest rate (percentage)");
                float interestRate = 0;
                float.TryParse(Console.ReadLine(), out interestRate);
                Console.WriteLine("Estimated insurance premium");
                float estInsPremium = 0;
                float.TryParse(Console.ReadLine(), out estInsPremium);
                vechilcek = calculator(purchasePrice - totalDeposit + estInsPremium, interestRate, 5);
            }
            return vechilcek;
        }
    }
}
       
    

